#!/bin/bash
source .env

./backend -port "$APP_PORT" -api-key "$APP_API_KEY"





