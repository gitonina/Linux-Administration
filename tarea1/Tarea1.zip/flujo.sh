#!/bin/bash

JUGADAS=('tulio' 'lulo' 'lana' 'tarro' 'patana' 'juanin' 'bodoque' 'tramoya') 




while true; do
  INDICES=$(( RANDOM % ${#JUGADAS[@]} ))
   echo "  ${JUGADAS[$INDICES]} "




          done
